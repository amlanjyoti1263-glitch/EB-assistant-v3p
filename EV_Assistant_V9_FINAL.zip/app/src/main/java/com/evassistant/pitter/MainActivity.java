package com.evassistant.pitter;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import androidx.core.content.FileProvider;
import java.io.File;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.Priority;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import android.provider.Settings;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import java.util.HashMap;
import java.util.Map;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_RECORD_AUDIO = 1001;
    private static final int REQ_AUDIO_FILE = 2001;
    private static final int REQ_LOCATION = 3001;
    private android.webkit.GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean speechReady = false;
    private boolean listeningWanted = false;
    private boolean permissionRequestPending = false;
    private boolean webReady = false;
    private boolean permissionDenied = false;
    private String pendingSpeechText = null;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean recognitionActive = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicInteger utteranceCounter = new AtomicInteger();
    private MediaPlayer radioPlayer;
    private ExoPlayer radioExoPlayer;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback fusedLocationCallback;
    private boolean locationRequestInProgress = false;
    private boolean locationPermissionRequestPending = false;
    private MediaRecorder voiceMessageRecorder;
    private File voiceMessageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                geoOrigin = origin; geoCallback = callback;
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = filePathCallback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("audio/*");
                    startActivityForResult(intent, REQ_AUDIO_FILE);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                webReady = true;
                if (permissionDenied) {
                    callJs("window.onNativeMicPermissionDenied && window.onNativeMicPermissionDenied();");
                } else if (hasRecordAudioPermission()) {
                    callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
                }
            }
        });
        webView.addJavascriptInterface(new AndroidVoiceBridge(), "AndroidVoice");

        initTextToSpeech();
        initSpeechRecognizer();
        webView.loadUrl("file:///android_asset/index.html");

        // Native permissions are requested sequentially. Android can ignore/drop a
        // second runtime-permission request while the first dialog is still open.
        handler.postDelayed(this::ensureMicrophonePermission, 350);
    }

    private boolean hasRecordAudioPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureMicrophonePermission() {
        if (hasRecordAudioPermission()) {
            permissionDenied = false;
            if (webReady) {
                callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
            }
            // Ask for location only after the mic permission flow is settled.
            handler.postDelayed(this::ensureLocationPermission, 450);
            return;
        }
        permissionDenied = false;
        permissionRequestPending = true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
    }

    private void openMicrophoneSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isLocationEnabled() {
        if (locationManager == null) return false;
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                return locationManager.isLocationEnabled();
            }
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) { return false; }
    }

    private void ensureLocationPermission() {
        if (!hasLocationPermission()) {
            if (locationPermissionRequestPending) return;
            locationPermissionRequestPending = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (!isLocationEnabled()) {
            callJs("window.onNativeLocationServicesOff && window.onNativeLocationServicesOff();");
            return;
        }
        getCurrentLocationForJs();
    }

    private void openLocationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        } catch (Exception ignored) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) { }
        }
    }

    private void getCurrentLocationForJs() {
        if (!hasLocationPermission()) {
            ensureLocationPermission();
            return;
        }
        if (!isLocationEnabled()) {
            callJs("window.onNativeLocationServicesOff && window.onNativeLocationServicesOff();");
            return;
        }
        if (fusedLocationClient == null) {
            callJs("window.onNativeLocationError && window.onNativeLocationError('Location provider unavailable');");
            return;
        }
        if (locationRequestInProgress) return;
        locationRequestInProgress = true;

        try {
            // First use a recent fused location. This avoids falsely reporting
            // "GPS unavailable" when the phone is already locked onto a location.
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, last -> {
                if (last != null && last.hasAccuracy() &&
                        last.getAccuracy() <= 1500f &&
                        System.currentTimeMillis() - last.getTime() <= 5 * 60 * 1000L) {
                    finishNativeLocation(last);
                    return;
                }
                requestFreshFusedLocation();
            }).addOnFailureListener(this, e -> requestFreshFusedLocation());
        } catch (SecurityException e) {
            locationRequestInProgress = false;
            callJs("window.onNativeLocationError && window.onNativeLocationError('Location permission required');");
        } catch (Exception e) {
            requestFreshFusedLocation();
        }
    }

    private void requestFreshFusedLocation() {
        if (!hasLocationPermission() || fusedLocationClient == null) {
            locationRequestInProgress = false;
            return;
        }
        try {
            LocationRequest request = new LocationRequest.Builder(
                    Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                    .setMinUpdateIntervalMillis(500L)
                    .setMaxUpdateDelayMillis(2000L)
                    .setWaitForAccurateLocation(false)
                    .setMaxUpdates(1)
                    .build();

            fusedLocationCallback = new LocationCallback() {
                @Override public void onLocationResult(LocationResult result) {
                    Location location = result == null ? null : result.getLastLocation();
                    if (location != null) finishNativeLocation(location);
                }
            };
            fusedLocationClient.requestLocationUpdates(
                    request, fusedLocationCallback, Looper.getMainLooper());
            handler.postDelayed(() -> {
                if (!locationRequestInProgress) return;
                try {
                    fusedLocationClient.getLastLocation().addOnSuccessListener(this, last -> {
                        if (last != null) finishNativeLocation(last);
                        else {
                            locationRequestInProgress = false;
                            cleanupLocationUpdates();
                            // Do not claim GPS is unavailable simply because a
                            // first fix was slow. The user can retry weather.
                            callJs("window.onNativeLocationError && window.onNativeLocationError('Location fix is taking longer than expected');");
                        }
                    });
                } catch (Exception ignored) {
                    locationRequestInProgress = false;
                    cleanupLocationUpdates();
                    callJs("window.onNativeLocationError && window.onNativeLocationError('Location fix is taking longer than expected');");
                }
            }, 30000L);
        } catch (SecurityException e) {
            locationRequestInProgress = false;
            cleanupLocationUpdates();
            callJs("window.onNativeLocationError && window.onNativeLocationError('Location permission required');");
        } catch (Exception e) {
            locationRequestInProgress = false;
            cleanupLocationUpdates();
            callJs("window.onNativeLocationError && window.onNativeLocationError('Location provider error');");
        }
    }

    private void finishNativeLocation(Location location) {
        if (location == null || !locationRequestInProgress) return;
        locationRequestInProgress = false;
        cleanupLocationUpdates();
        sendNativeLocation(location);
    }

    private void sendNativeLocation(Location location) {
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        float accuracy = location.hasAccuracy() ? location.getAccuracy() : -1f;
        callJs("window.onNativeLocation && window.onNativeLocation(" + lat + "," + lon + "," + accuracy + ");");
    }

    private void cleanupLocationUpdates() {
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        locationListener = null;
        if (fusedLocationClient != null && fusedLocationCallback != null) {
            try { fusedLocationClient.removeLocationUpdates(fusedLocationCallback); } catch (Exception ignored) { }
        }
        fusedLocationCallback = null;
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(new Locale("hi", "IN"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech.setLanguage(Locale.US);
                }
                textToSpeech.setSpeechRate(1.0f);
                textToSpeech.setPitch(1.08f);
                speechReady = true;
                callJs("window.onNativeTTSReady && window.onNativeTTSReady();");
                if (pendingSpeechText != null) {
                    String pending = pendingSpeechText;
                    pendingSpeechText = null;
                    speakNow(pending);
                }
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            textToSpeech.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }

                @Override public void onDone(String utteranceId) {
                    runOnUiThread(() -> callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();"));
                }

                @Override public void onError(String utteranceId) {
                    runOnUiThread(() -> callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();"));
                }
            });
        }
    }

    private void initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                recognitionActive = true;
                callJs("window.onNativeSpeechReady && window.onNativeSpeechReady();");
            }

            @Override public void onBeginningOfSpeech() {
                recognitionActive = true;
                callJs("window.onNativeSpeechStarted && window.onNativeSpeechStarted();");
            }

            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }

            @Override public void onEndOfSpeech() {
                callJs("window.onNativeSpeechEnded && window.onNativeSpeechEnded();");
            }

            @Override public void onError(int error) {
                recognitionActive = false;
                if (!listeningWanted) return;
                String message = "Speech error " + error;
                callJs("window.onNativeSpeechError && window.onNativeSpeechError(" + quote(message) + ");");
                // Restart is owned by the JavaScript voice lifecycle. Keeping a
                // single restart owner prevents Android + JS from fighting each other.
            }

            @Override public void onResults(Bundle results) {
                recognitionActive = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                listeningWanted = false;
                if (!text.trim().isEmpty()) {
                    callJs("window.onNativeSpeechFinal && window.onNativeSpeechFinal(" + quote(text) + ");");
                } else {
                    callJs("window.onNativeSpeechError && window.onNativeSpeechError('No speech detected');");
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    callJs("window.onNativeSpeechPartial && window.onNativeSpeechPartial(" + quote(matches.get(0)) + ");");
                }
            }

            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startNativeRecognition() {
        if (speechRecognizer == null) {
            callJs("window.onNativeSpeechError && window.onNativeSpeechError('Speech recognition is unavailable on this device');");
            return;
        }
        if (!hasRecordAudioPermission()) {
            listeningWanted = true;
            ensureMicrophonePermission();
            return;
        }

        // Do not cancel here. A cancel can emit ERROR_CLIENT and create a
        // second restart cycle. Each new session is started only after the
        // previous session has ended with results or an error.
        if (recognitionActive) return;

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        try {
            recognitionActive = true;
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            recognitionActive = false;
            callJs("window.onNativeSpeechError && window.onNativeSpeechError(" + quote(e.getMessage() == null ? "Unable to start microphone" : e.getMessage()) + ");");
        }
    }

    private void stopNativeRecognition() {
        listeningWanted = false;
        recognitionActive = false;
        if (speechRecognizer != null) {
            try { speechRecognizer.stopListening(); } catch (Exception ignored) { }
            try { speechRecognizer.cancel(); } catch (Exception ignored) { }
        }
    }

    private void stopNativeRadio() {
        if (radioExoPlayer != null) {
            try { radioExoPlayer.stop(); } catch (Exception ignored) { }
            try { radioExoPlayer.release(); } catch (Exception ignored) { }
            radioExoPlayer = null;
        }
        if (radioPlayer != null) {
            try { radioPlayer.stop(); } catch (Exception ignored) { }
            try { radioPlayer.reset(); } catch (Exception ignored) { }
            try { radioPlayer.release(); } catch (Exception ignored) { }
            radioPlayer = null;
        }
    }

    private void startNativeRadio(String url) {
        final String streamUrl = url == null ? "" : url.trim();
        if (streamUrl.isEmpty()) {
            callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote("Radio URL missing") + ");");
            return;
        }
        stopNativeRadio();
        try {
            DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                    .setUserAgent("EV-Assistant/8.0 (Android)")
                    .setAllowCrossProtocolRedirects(true);
            Map<String,String> headers = new HashMap<>();
            headers.put("Icy-MetaData", "1");
            httpFactory.setDefaultRequestProperties(headers);
            DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(httpFactory);
            radioExoPlayer = new ExoPlayer.Builder(this)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .build();
            radioExoPlayer.addListener(new androidx.media3.common.Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if (state == androidx.media3.common.Player.STATE_READY && radioExoPlayer != null && radioExoPlayer.isPlaying()) {
                        callJs("window.onNativeRadioPlaying && window.onNativeRadioPlaying();");
                    }
                    if (state == androidx.media3.common.Player.STATE_ENDED) {
                        stopNativeRadio();
                        callJs("window.onNativeRadioStopped && window.onNativeRadioStopped('ended');");
                    }
                }
                @Override public void onPlayerError(PlaybackException error) {
                    String msg = error == null ? "Radio stream error" : String.valueOf(error.getMessage());
                    stopNativeRadio();
                    callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote(msg) + ");");
                }
            });
            radioExoPlayer.setMediaItem(MediaItem.fromUri(streamUrl));
            radioExoPlayer.prepare();
            radioExoPlayer.play();
        } catch (Exception e) {
            stopNativeRadio();
            callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote(e.getMessage() == null ? "Unable to load radio stream" : e.getMessage()) + ");");
        }
    }

    private void openYouTubeSearch(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) q = "music";
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)));
            startActivity(intent);
        } catch (Exception e) {
            callJs("window.onExternalMediaError && window.onExternalMediaError(" + quote("YouTube open nahi hua") + ");");
        }
    }

    private void startVoiceMessageRecording() {
        if (voiceMessageRecorder != null) {
            callJs("window.onVoiceMessageRecording && window.onVoiceMessageRecording(true);");
            return;
        }
        if (!hasRecordAudioPermission()) {
            ensureMicrophonePermission();
            callJs("window.onVoiceMessageError && window.onVoiceMessageError(" + quote("Microphone permission chahiye") + ");");
            return;
        }
        try {
            voiceMessageFile = new File(getCacheDir(), "EB_voice_message_" + System.currentTimeMillis() + ".m4a");
            voiceMessageRecorder = new MediaRecorder(this);
            voiceMessageRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            voiceMessageRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            voiceMessageRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            voiceMessageRecorder.setAudioEncodingBitRate(128000);
            voiceMessageRecorder.setAudioSamplingRate(44100);
            voiceMessageRecorder.setOutputFile(voiceMessageFile.getAbsolutePath());
            voiceMessageRecorder.prepare();
            voiceMessageRecorder.start();
            callJs("window.onVoiceMessageRecording && window.onVoiceMessageRecording(true);");
        } catch (Exception e) {
            stopVoiceMessageRecorder(false);
            callJs("window.onVoiceMessageError && window.onVoiceMessageError(" + quote("Voice recording start nahi hua") + ");");
        }
    }

    private void stopVoiceMessageRecorder(boolean shareToWhatsApp) {
        if (voiceMessageRecorder == null) return;
        try { voiceMessageRecorder.stop(); } catch (Exception ignored) { }
        try { voiceMessageRecorder.reset(); } catch (Exception ignored) { }
        try { voiceMessageRecorder.release(); } catch (Exception ignored) { }
        voiceMessageRecorder = null;

        if (shareToWhatsApp && voiceMessageFile != null && voiceMessageFile.exists() && voiceMessageFile.length() > 0) {
            try {
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", voiceMessageFile);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("audio/mp4");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (getPackageManager().getLaunchIntentForPackage("com.whatsapp") != null) {
                    send.setPackage("com.whatsapp");
                }
                startActivity(send);
                callJs("window.onVoiceMessageShared && window.onVoiceMessageShared();");
            } catch (Exception e) {
                callJs("window.onVoiceMessageError && window.onVoiceMessageError(" + quote("WhatsApp/share screen open nahi hua") + ");");
            }
        }
        callJs("window.onVoiceMessageRecording && window.onVoiceMessageRecording(false);");
    }

    private void callJs(String javascript) {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript("javascript:(function(){try{" + javascript + "}catch(e){}})();", null));
    }

    private static String quote(String value) {
        if (value == null) value = "";
        return org.json.JSONObject.quote(value);
    }

    private void speakNow(String text) {
        if (textToSpeech == null || !speechReady) {
            pendingSpeechText = text == null ? "" : text;
            return;
        }
        stopNativeRecognition();
        String value = text == null ? "" : text;
        if (value.trim().isEmpty()) {
            callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
            return;
        }
        String utteranceId = "ev_assistant_" + utteranceCounter.incrementAndGet();
        Bundle params = new Bundle();
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId);
        int result = textToSpeech.speak(value, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (result == TextToSpeech.ERROR) {
            callJs("window.onNativeSpeechError && window.onNativeSpeechError(\"TTS speak failed\");");
            callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
        }
    }

    private class AndroidVoiceBridge {
        @JavascriptInterface public boolean isNativeVoiceAvailable() {
            return speechRecognizer != null && textToSpeech != null;
        }

        @JavascriptInterface public boolean isTTSReady() {
            return speechReady;
        }

        @JavascriptInterface public void startListening() {
            runOnUiThread(() -> {
                listeningWanted = true;
                startNativeRecognition();
            });
        }

        @JavascriptInterface public void stopListening() {
            runOnUiThread(MainActivity.this::stopNativeRecognition);
        }

        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (!speechReady) {
                    pendingSpeechText = text == null ? "" : text;
                    return;
                }
                speakNow(text);
            });
        }

        @JavascriptInterface public void requestLocation() {
            runOnUiThread(MainActivity.this::ensureLocationPermission);
        }

        @JavascriptInterface public void openLocationSettings() {
            runOnUiThread(MainActivity.this::openLocationSettings);
        }

        @JavascriptInterface public boolean hasLocationPermission() {
            return MainActivity.this.hasLocationPermission();
        }

        @JavascriptInterface public boolean isLocationEnabled() {
            return MainActivity.this.isLocationEnabled();
        }

        @JavascriptInterface public void getCurrentLocation() {
            runOnUiThread(MainActivity.this::getCurrentLocationForJs);
        }

        @JavascriptInterface public void openMicrophoneSettings() {
            runOnUiThread(MainActivity.this::openMicrophoneSettings);
        }

        @JavascriptInterface public void playRadio(String url) {
            runOnUiThread(() -> startNativeRadio(url));
        }

        @JavascriptInterface public void stopRadio() {
            runOnUiThread(() -> {
                stopNativeRadio();
                callJs("window.onNativeRadioStopped && window.onNativeRadioStopped('stopped');");
            });
        }

        @JavascriptInterface public void openYouTubeSearch(String query) {
            runOnUiThread(() -> openYouTubeSearch(query));
        }

        @JavascriptInterface public void startVoiceMessageRecording() {
            runOnUiThread(() -> {
                try { stopNativeRecognition(); } catch (Exception ignored) { }
                startVoiceMessageRecording();
            });
        }

        @JavascriptInterface public void stopVoiceMessageAndShare() {
            runOnUiThread(() -> stopVoiceMessageRecorder(true));
        }

        @JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_AUDIO_FILE) return;
        if (fileChooserCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) results = new Uri[]{uri};
        }
        ValueCallback<Uri[]> callback = fileChooserCallback;
        fileChooserCallback = null;
        callback.onReceiveValue(results);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            locationPermissionRequestPending = false;
            boolean granted = hasLocationPermission();
            if (geoCallback != null && geoOrigin != null) {
                geoCallback.invoke(geoOrigin, granted, false);
                geoCallback = null; geoOrigin = null;
            }
            if (granted) {
                callJs("window.onNativeLocationPermissionGranted && window.onNativeLocationPermissionGranted();");
                if (isLocationEnabled()) getCurrentLocationForJs();
                else callJs("window.onNativeLocationServicesOff && window.onNativeLocationServicesOff();");
            } else {
                callJs("window.onNativeLocationPermissionDenied && window.onNativeLocationPermissionDenied();");
            }
            return;
        }
        if (requestCode != REQ_RECORD_AUDIO) return;

        permissionRequestPending = false;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            permissionDenied = false;
            listeningWanted = true;
            if (webReady) {
                callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
                startNativeRecognition();
            }
            handler.postDelayed(this::ensureLocationPermission, 450);
        } else {
            permissionDenied = true;
            listeningWanted = false;
            if (webReady) {
                callJs("window.onNativeMicPermissionDenied && window.onNativeMicPermissionDenied();");
            }
            Toast.makeText(this,
                    "Microphone permission deny hai. App Settings me Microphone ko Allow karein.",
                    Toast.LENGTH_LONG).show();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(() -> {
            if (hasLocationPermission() && isLocationEnabled()) getCurrentLocationForJs();
        }, 300);
    }

    @Override
    protected void onDestroy() {
        cleanupLocationUpdates();
        stopNativeRecognition();
        stopNativeRadio();
        stopVoiceMessageRecorder(false);
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
