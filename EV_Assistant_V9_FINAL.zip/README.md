# EV Assistant V9 — Core Stability + Media

V9 is based on the uploaded V8 Core Stability project and consolidates the agreed requirements.

## Core fixes
- Native Android fused location (`FINE + COARSE`) with sequential runtime permission flow.
- Location request is made after microphone permission dialog settles, avoiding Android permission-dialog races.
- Fresh high-accuracy location request with a 30-second fix window and recent-location reuse.
- No IP-location weather fallback.
- Weather current observation is separated from hourly forecast; current precipitation has priority for "abhi baarish ho rahi hai".
- Rain-stop estimates use future hourly precipitation/rain/showers and do not claim certainty.
- Media3 ExoPlayer for MP3/AAC/progressive/HLS radio streams, with redirects and Icecast metadata request.
- Native voice lifecycle remains centralized with screen-on EV/Beli wake-word operation.
- Song title fuzzy matching preserved and last local-song position is remembered in local storage.
- Media remains voice-controllable while playing; normal song/radio audio is ignored.
- Studio recommended settings and conversation-initiative selector added.
- Safe YouTube search handoff to the YouTube app/browser.
- Voice-message recording + WhatsApp/share handoff; user still chooses the chat and presses Send.
- Existing Piiitter default + Amlan second + custom-name settings retained.
- Screen-off microphone wake-up is NOT included by design.

## Important external-service limitation
A webpage such as `https://akashvani.gov.in/radio/live.php` is a live-radio web page, not necessarily a direct audio stream URL. Media3 can play direct MP3/AAC/HLS stream URLs; if a broadcaster only exposes a player webpage, that page must be used/opened separately or its actual stream endpoint must be supplied.

## Build
GitHub Actions workflow builds `app-debug.apk`.
Version: 1.9 / versionCode 10.
